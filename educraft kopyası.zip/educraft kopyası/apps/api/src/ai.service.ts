import { Injectable, BadRequestException, ServiceUnavailableException } from "@nestjs/common";
import { ConfigService } from "@nestjs/config";
import { aiGenerateRequestSchema, gameContentSchema, GameContent } from "@educraft/schemas";

@Injectable()
export class AiService {
  constructor(private config: ConfigService) {}

  async generate(raw: unknown): Promise<GameContent> {
    const input = aiGenerateRequestSchema.parse(raw);
    const apiKey = this.config.get<string>("AI_API_KEY");
    if (!apiKey) return this.safeFallback(input);
    const baseUrl = this.config.get("AI_BASE_URL", "https://openrouter.io/api/v1");
    const model = this.config.get("AI_MODEL", "gpt-4o-mini");
    const system = "You create only educational game content. Never output maps, worlds, terrain, buildings, coordinates, schematics, WorldEdit, Minecraft commands, OP commands, or arbitrary actions. Output JSON only. locationKey values must use existing EDU_ keys.";
    let lastError: unknown;
    for (let attempt = 0; attempt < 2; attempt++) {
      try {
        const response = await fetch(`${baseUrl}/chat/completions`, {
          method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
          body: JSON.stringify({ model, temperature: 0.4, response_format: { type: "json_object" }, messages: [
            { role: "system", content: system },
            { role: "user", content: JSON.stringify(input) },
          ] }),
        });
        if (!response.ok) throw new Error(`AI upstream ${response.status}`);
        const json = await response.json() as any;
        const content = JSON.parse(json.choices?.[0]?.message?.content || "{}");
        return gameContentSchema.parse(content);
      } catch (error) { lastError = error; }
    }
    throw new ServiceUnavailableException("AI içeriği oluşturulamadı. Lütfen tekrar deneyin.", { cause: lastError as Error });
  }

  private safeFallback(input: any): GameContent {
    if (input.questionCount < 1) throw new BadRequestException("En az bir soru gerekli.");
    return {
      gameTitle: input.title,
      questions: Array.from({ length: input.questionCount }, (_, index) => ({
        prompt: `${input.topic} konusu için örnek soru ${index + 1}`,
        options: ["A seçeneği", "B seçeneği", "C seçeneği", "D seçeneği"],
        correctOption: 0,
        explanation: "Bu içerik AI bağlantısı ayarlanana kadar güvenli başlangıç içeriğidir.",
        hint: "Sorudaki temel kavramı hatırla.",
        difficulty: input.difficulty,
      })),
      quests: Array.from({ length: input.questCount }, (_, index) => ({
        title: `${input.topic} görevi ${index + 1}`, description: "Eğitim içeriğini tamamla.", type: "ANSWER" as const,
        steps: [{ title: "Soruyu çöz", type: "ANSWER" as const, description: "Soruyu cevapla.", rewardXp: 20 }],
        rewardXp: 40,
      })),
      npcs: [{ name: "Edu Rehberi", role: "Eğitim rehberi", locationKey: "EDU_NPC_GUIDE_01", dialogue: ["Hazırsan başlayalım."] }],
      puzzles: [], boss: { enabled: false, name: "", messages: [], phases: [], rewardXp: 0 }, rewards: [{ label: "Tamamlama XP", type: "XP", amount: 50 }],
    };
  }
}