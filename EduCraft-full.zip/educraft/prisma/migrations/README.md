# Prisma migrations

Migration history is intentionally kept out of the initial source bundle because the target PostgreSQL instance is chosen by the host. On the first deployment run:

```bash
npm run db:migrate
```

For CI/production after committing the generated migration directory, use:

```bash
npx prisma migrate deploy --schema prisma/schema.prisma
```

Do not use `db:push` in production.