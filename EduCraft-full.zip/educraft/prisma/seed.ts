import { PrismaClient, Role, Difficulty, GameMode, ArenaStatus } from "@prisma/client";
import * as bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  const passwordHash = await bcrypt.hash("ChangeMe!123", 12);
  const school = await prisma.school.upsert({
    where: { code: "EDU-DEMO" },
    update: {},
    create: { name: "EduCraft Demo Okulu", code: "EDU-DEMO" },
  });

  const admin = await prisma.user.upsert({
    where: { email: "admin@educraft.local" },
    update: { passwordHash },
    create: { email: "admin@educraft.local", passwordHash, firstName: "Sistem", lastName: "Admin", role: Role.ADMIN, schoolId: school.id },
  });
  const teacher = await prisma.user.upsert({
    where: { email: "teacher@educraft.local" },
    update: { passwordHash },
    create: { email: "teacher@educraft.local", passwordHash, firstName: "Ayşe", lastName: "Öğretmen", role: Role.TEACHER, schoolId: school.id },
  });
  const student = await prisma.user.upsert({
    where: { email: "student@educraft.local" },
    update: { passwordHash },
    create: { email: "KralPlayer@educraft.local", passwordHash, firstName: "Kral", lastName: "Player", role: Role.STUDENT, schoolId: school.id },
  });

  const subject = await prisma.subject.create({ data: { name: "Matematik", schoolId: school.id } });
  const topic = await prisma.topic.create({ data: { name: "Denklemler", subjectId: subject.id } });
  const classRoom = await prisma.class.upsert({
    where: { joinCode: "EDU-7A-X82K" },
    update: {},
    create: { name: "7-A", joinCode: "EDU-7A-X82K", gradeLevel: "7. Sınıf", description: "Matematik macera sınıfı", schoolId: school.id, teacherId: teacher.id },
  });
  await prisma.classMember.upsert({ where: { classId_userId: { classId: classRoom.id, userId: student.id } }, update: {}, create: { classId: classRoom.id, userId: student.id } });
  await prisma.studentProgress.upsert({ where: { userId: student.id }, update: {}, create: { userId: student.id, xp: 1240, level: 8, gamesPlayed: 12, correctAnswers: 48, wrongAnswers: 9 } });
  await prisma.arena.createMany({ data: [
    { name: "Arena 1", world: "educraft", regionKey: "EDU_ARENA_1", status: ArenaStatus.AVAILABLE },
    { name: "Arena 2", world: "educraft", regionKey: "EDU_ARENA_2", status: ArenaStatus.AVAILABLE },
    { name: "Arena 3", world: "educraft", regionKey: "EDU_ARENA_3", status: ArenaStatus.AVAILABLE },
  ], skipDuplicates: true });

  const existing = await prisma.game.findFirst({ where: { title: "Kayıp Cebir Krallığı" } });
  if (!existing) {
    const game = await prisma.game.create({
      data: {
        title: "Kayıp Cebir Krallığı", gradeLevel: "7. Sınıf", durationMinutes: 30,
        difficulty: Difficulty.ADAPTIVE, adaptiveMode: true, mode: GameMode.CLASS,
        creatorId: teacher.id, classId: classRoom.id, subjectId: subject.id, topicId: topic.id,
        questions: { create: [
          { prompt: "2 + 2 kaçtır?", options: ["3", "4", "5", "6"], correctOption: 1, explanation: "İki ile iki toplandığında dört eder.", hint: "İki çift elmayı birleştir.", difficulty: Difficulty.EASY, topicId: topic.id },
          { prompt: "x + 5 = 12 ise x kaçtır?", options: ["5", "6", "7", "8"], correctOption: 2, explanation: "Her iki taraftan 5 çıkarılır: x = 7.", hint: "Sabit sayıyı karşı tarafa çıkarma olarak taşı.", difficulty: Difficulty.MEDIUM, topicId: topic.id },
        ] },
        quests: { create: { title: "Kralın Mührünü Bul", description: "Denklemleri çözerek mühre ulaş.", type: "ANSWER", rewardXp: 120, steps: { create: [
          { title: "Rehberle konuş", type: "TALK", description: "EDU_NPC_GUIDE_01 bölgesindeki rehberle konuş.", locationKey: "EDU_NPC_GUIDE_01", rewardXp: 10, order: 0 },
          { title: "İlk denklemi çöz", type: "ANSWER", description: "2 + 2 sorusunu cevapla.", rewardXp: 40, order: 1 },
        ] } } },
        npcs: { create: { name: "Ada", role: "Matematik Rehberi", locationKey: "EDU_NPC_GUIDE_01", dialogue: ["Hoş geldin gezgin.", "Bugün denklemlerle krallığı kurtaracağız."] } },
        puzzles: { create: { type: "MATH", title: "Mühürlü Kapı", question: "3 × 4 kaçtır?", data: {}, answer: "12", rewardXp: 50 } },
        boss: { create: { name: "Bilinmeyen", enabled: true, messages: ["Soruları çözmeden beni yenemezsin!"], phases: [{ "order": 1, "label": "İlk Faz", "questionIds": [], "mechanic": "QUESTION_DAMAGE" }], rewardXp: 200 } },
        rewards: { create: [{ label: "Cebir Çırağı", type: "BADGE" }, { label: "XP Ödülü", type: "XP", amount: 200 }] },
      },
    });
    await prisma.auditLog.create({ data: { userId: admin.id, action: "SEED_GAME_CREATED", targetType: "Game", targetId: game.id, metadata: { source: "seed" } } });
  }
}

main().finally(() => prisma.$disconnect());