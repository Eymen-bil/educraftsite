import { z } from "zod";

export const roleSchema = z.enum(["ADMIN", "SCHOOL_ADMIN", "TEACHER", "STUDENT"]);
export const gameModeSchema = z.enum(["CLASS", "SOLO"]);
export const difficultySchema = z.enum(["EASY", "MEDIUM", "HARD", "ADAPTIVE"]);
export const questTypeSchema = z.enum([
  "TALK", "ANSWER", "COLLECT", "TRAVEL", "BUILD", "PUZZLE", "BOSS", "DIALOGUE", "COMPLETE",
]);
export const puzzleTypeSchema = z.enum(["QUESTION", "SEQUENCE", "MATCH", "LOGIC", "CODE", "MEMORY", "MATH"]);

export const questionSchema = z.object({
  id: z.string().optional(),
  prompt: z.string().min(1).max(2000),
  options: z.array(z.string().min(1).max(500)).min(2).max(6),
  correctOption: z.number().int().min(0).max(5),
  explanation: z.string().max(2000),
  hint: z.string().max(1000).optional(),
  difficulty: difficultySchema,
});

export const questStepSchema = z.object({
  title: z.string().min(1).max(160),
  type: questTypeSchema,
  description: z.string().max(1000),
  locationKey: z.string().regex(/^EDU_[A-Z0-9_]+$/).optional(),
  rewardXp: z.number().int().min(0).max(10000),
});

export const npcSchema = z.object({
  id: z.string().optional(),
  name: z.string().min(1).max(80),
  role: z.string().max(120),
  locationKey: z.string().regex(/^EDU_[A-Z0-9_]+$/),
  dialogue: z.array(z.string().min(1).max(1000)).min(1).max(20),
  linkedQuestId: z.string().optional(),
});

export const puzzleSchema = z.object({
  id: z.string().optional(),
  type: puzzleTypeSchema,
  title: z.string().min(1).max(160),
  question: z.string().max(2000),
  data: z.record(z.unknown()).default({}),
  answer: z.string().max(500),
  rewardXp: z.number().int().min(0).max(10000),
});

export const bossSchema = z.object({
  enabled: z.boolean(),
  name: z.string().max(120),
  messages: z.array(z.string().max(500)).max(20),
  phases: z.array(z.object({
    order: z.number().int().positive(),
    label: z.string().max(120),
    questionIds: z.array(z.string()).max(100),
    mechanic: z.enum(["QUESTION_DAMAGE", "SEQUENCE", "PUZZLE_GATE"]),
  })).max(10),
  rewardXp: z.number().int().min(0).max(10000),
});

export const rewardSchema = z.object({
  label: z.string().min(1).max(160),
  type: z.enum(["XP", "BADGE", "COSMETIC"]),
  amount: z.number().int().min(0).max(100000).optional(),
});

export const gameContentSchema = z.object({
  gameTitle: z.string().min(1).max(160),
  questions: z.array(questionSchema).max(100),
  quests: z.array(z.object({
    title: z.string().min(1).max(160),
    description: z.string().max(1000),
    type: questTypeSchema,
    steps: z.array(questStepSchema).max(30),
    rewardXp: z.number().int().min(0).max(10000),
  })).max(30),
  npcs: z.array(npcSchema).max(30),
  puzzles: z.array(puzzleSchema).max(30),
  boss: bossSchema,
  rewards: z.array(rewardSchema).max(30),
});

export const createGameSchema = z.object({
  title: z.string().min(2).max(160),
  subject: z.string().min(2).max(80),
  topic: z.string().min(2).max(120),
  gradeLevel: z.string().min(1).max(40),
  durationMinutes: z.number().int().min(5).max(240),
  difficulty: difficultySchema,
  adaptiveMode: z.boolean().default(true),
  mode: gameModeSchema,
});

export const minecraftActionSchema = z.discriminatedUnion("type", [
  z.object({ type: z.literal("SHOW_DIALOGUE"), npcId: z.string(), dialogueId: z.string() }),
  z.object({ type: z.literal("START_QUIZ"), questionId: z.string() }),
  z.object({ type: z.literal("START_PUZZLE"), puzzleId: z.string() }),
  z.object({ type: z.literal("UPDATE_QUEST"), questId: z.string(), stepIndex: z.number().int().min(0) }),
  z.object({ type: z.literal("BOSS_EVENT"), bossId: z.string(), phase: z.number().int().positive() }),
  z.object({ type: z.literal("TELEPORT_TO_ARENA"), arenaId: z.string() }),
  z.object({ type: z.literal("RETURN_TO_LOBBY") }),
]);

export const aiGenerateRequestSchema = z.object({
  title: z.string().min(2).max(160),
  subject: z.string().min(2).max(80),
  topic: z.string().min(2).max(120),
  gradeLevel: z.string().min(1).max(40),
  difficulty: difficultySchema,
  questionCount: z.number().int().min(1).max(50),
  questCount: z.number().int().min(0).max(10),
});

export type GameContent = z.infer<typeof gameContentSchema>;
export type CreateGameInput = z.infer<typeof createGameSchema>;
export type MinecraftAction = z.infer<typeof minecraftActionSchema>;