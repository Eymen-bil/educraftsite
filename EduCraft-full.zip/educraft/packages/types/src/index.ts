export type Role = "ADMIN" | "SCHOOL_ADMIN" | "TEACHER" | "STUDENT";
export type SessionStatus = "WAITING" | "STARTING" | "RUNNING" | "PAUSED" | "COMPLETED" | "CLOSED" | "CLEANING";
export type ArenaStatus = "AVAILABLE" | "IN_USE" | "CLEANING" | "DISABLED";
export type LiveEventType =
  | "PLAYER_JOINED" | "PLAYER_LEFT" | "SESSION_STARTED" | "PLAYER_ANSWERED"
  | "QUEST_PROGRESS" | "PUZZLE_COMPLETED" | "BOSS_EVENT" | "PLAYER_COMPLETED"
  | "SESSION_PAUSED" | "SESSION_RESUMED" | "SESSION_CLOSED";

export interface AuthUser {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  role: Role;
  schoolId?: string | null;
}