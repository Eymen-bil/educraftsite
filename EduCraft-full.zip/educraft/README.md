# EduCraft

EduCraft, sabit ve önceden tanımlı Minecraft arenalarında eğitimsel oyun içeriği çalıştıran production-oriented bir monorepo'dur. AI hiçbir zaman world, map, terrain, koordinat veya Minecraft komutu üretmez; yalnızca backend'in Zod şemasıyla doğruladığı eğitim içeriğini üretir.

## Paketler

- `apps/web`: Next.js 15 App Router web uygulaması
- `apps/api`: NestJS REST + WebSocket API
- `packages/schemas`: API ve AI payload'ları için ortak Zod şemaları
- `packages/types`: ortak TypeScript tipleri
- `prisma`: PostgreSQL veri modeli ve seed
- `minecraft/plugin`: Paper 1.21.8 / Java 21 bridge plugin iskeleti
- `docs`: deployment, arena ve güvenlik notları

## Local kurulum

```bash
cp .env.example .env
npm install
docker compose up -d postgres
npm run db:generate
npm run db:migrate
npm run db:seed
npm run dev
```

Web `http://localhost:3000`, API `http://localhost:4000` ve health check `http://localhost:4000/api/health` adresindedir.

Seed hesapları:

| Rol | E-posta | Şifre |
| --- | --- | --- |
| ADMIN | admin@educraft.local | ChangeMe!123 |
| TEACHER | teacher@educraft.local | ChangeMe!123 |
| STUDENT | student@educraft.local | ChangeMe!123 |

İlk açılıştan sonra bu şifreleri değiştir. Seed yalnızca local başlangıç içindir.

## Production

Bir VPS üzerinde `docker compose up -d --build` çalıştırılabilir. Web ve API'yi ayrı domain/subdomain arkasında reverse proxy ile yayınla, PostgreSQL'i public açma, `.env` dosyasını repoya koyma. Statik hosting bu monorepo için yeterli değildir; gerçek authentication, PostgreSQL, WebSocket ve Minecraft bridge nedeniyle Node çalıştırabilen bir host gerekir.

Detaylı kurulum:

- `docs/architecture.md`
- `docs/deployment.md`
- `docs/minecraft.md`
- `docs/security.md`

## Güvenlik sınırları

Backend yalnızca whitelist edilmiş structured action'lar yayınlar. Plugin gelen payload içinden komut çalıştırmaz. Arena, dünya ve location bilgileri AI çıktısından değil, veritabanındaki önceden tanımlı kayıtlar üzerinden seçilir. Minecraft bridge istekleri `timestamp + nonce + HMAC-SHA256` imzası ve replay koruması kullanır.