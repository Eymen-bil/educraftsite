# Security checklist

- Secret'lar source code'a yazılmaz; `.env` ve hosting secret store kullanılır.
- Access token kısa ömürlü, refresh token hash'li ve rotation'lıdır.
- Global JWT + RBAC guard bütün private endpoint'lerde çalışır.
- Minecraft bridge timestamp, nonce ve HMAC-SHA256 ile imzalanır; nonce tekrar kullanılamaz.
- AI içeriği Zod schema parse edilmeden veritabanına yazılmaz.
- Arena seçimi yalnızca `Arena.status = AVAILABLE` kayıtlarından transaction ile yapılır.
- Frontend veya AI Minecraft command payload'ı gönderemez.
- Production'da HTTPS, PostgreSQL private network, rate limit/WAF ve merkezi structured logging eklenmelidir.