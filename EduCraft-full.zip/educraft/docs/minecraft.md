# Minecraft / Paper 1.21.8

1. Java 21 ve Paper 1.21.8 kur.
2. `minecraft/plugin` içinden `./gradlew build` ile jar üret.
3. Jar'ı Paper `plugins` klasörüne kopyala.
4. `plugins/EduCraft/config.yml` içindeki API URL, key, secret ve sabit world adını doldur.
5. WorldGuard üzerinde `EDU_ARENA_1`, `EDU_ARENA_2`, `EDU_ARENA_3` bölgelerini önceden oluştur ve API Arena kayıtlarıyla aynı isimleri kullan.
6. Lobby ve arena location key registry'sini server konfigürasyonunda tamamla.

Plugin HTTP işlerini async yapar; Bukkit world/player işlemlerini main thread'e taşır. Plugin tarafından `/execute`, `/op`, `/stop`, `/fill`, WorldEdit veya başka bir arbitrary command çağrılmaz.