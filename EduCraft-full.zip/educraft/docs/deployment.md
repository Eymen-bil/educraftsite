# Deployment

## VPS / Docker

1. Docker ve Docker Compose kur.
2. Repo'yu sunucuya al, `.env.example` dosyasını `.env` olarak kopyala.
3. `JWT_SECRET`, `JWT_REFRESH_SECRET`, `MINECRAFT_API_SECRET` için uzun random değerler ver.
4. `docker compose up -d --build`
5. `docker compose exec api npx prisma migrate deploy --schema prisma/schema.prisma`
6. İstersen ilk local hesapları oluşturmak için `docker compose exec api npx tsx prisma/seed.ts` çalıştır; production'da seed parolalarını değiştir.
7. Nginx/Caddy ile `app.domain.com → web:3000`, `api.domain.com → api:4000` proxy et. Web tarafında `NEXT_PUBLIC_API_URL` değerini public API URL'i yapıp web image'ını yeniden build et.

API ve Web'i çalıştıran bir host gerekir. GitHub Pages gibi yalnızca statik dosya sunan hosting'ler authentication, PostgreSQL ve WebSocket katmanını çalıştıramaz.