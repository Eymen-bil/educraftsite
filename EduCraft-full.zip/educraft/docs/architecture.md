# Architecture

Web ve API ayrı Node servisleridir. Web, access token ile API'ye REST istekleri gönderir; canlı öğretmen ekranı Socket.IO namespace `/live` üzerinden session room'larına bağlanır. API Prisma üzerinden PostgreSQL'e erişir. Minecraft bridge yalnızca imzalı istekleri kabul eder ve structured action whitelist'i ile hareket eder.

## Session lifecycle

`WAITING → STARTING → RUNNING → PAUSED/RUNNING → COMPLETED → CLEANING → CLOSED`

Arena allocation transaction içinde yapılır. Session CLOSED olduğunda arena AVAILABLE durumuna döner. Server recovery için plugin, backend'den stale session bilgisi alır; hiçbir zaman tüm dünyayı resetlemez.

## AI boundary

`packages/schemas/src/index.ts` içindeki `gameContentSchema`, AI çıktısının tek kabul kapısıdır. `AiService` iki deneme yapar ve schema parse başarısızsa çıktıyı kaydetmez. AI isteği yalnızca eğitimsel alanları içerir.