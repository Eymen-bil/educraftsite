package com.educraft.plugin;

import com.google.gson.JsonObject;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Set;

/**
 * The only place where backend actions become Minecraft effects.
 * There is deliberately no command execution API in this class.
 */
public final class SafeActionDispatcher {
    private static final Set<String> ALLOWED = Set.of(
            "SHOW_DIALOGUE", "START_QUIZ", "START_PUZZLE", "UPDATE_QUEST",
            "BOSS_EVENT", "TELEPORT_TO_ARENA", "RETURN_TO_LOBBY"
    );
    private final JavaPlugin plugin;

    public SafeActionDispatcher(JavaPlugin plugin) { this.plugin = plugin; }

    public void dispatch(JsonObject action) {
        String type = action.has("type") ? action.get("type").getAsString() : "";
        if (!ALLOWED.contains(type)) {
            plugin.getLogger().warning("Rejected non-whitelisted EduCraft action: " + type);
            return;
        }
        // Every case resolves server-owned keys. No arbitrary XYZ, command or block payload is accepted.
        switch (type) {
            case "SHOW_DIALOGUE", "START_QUIZ", "START_PUZZLE", "UPDATE_QUEST", "BOSS_EVENT" -> {
                plugin.getLogger().info("Structured action accepted: " + type);
            }
            case "TELEPORT_TO_ARENA" -> {
                String arenaKey = action.get("arenaId").getAsString();
                if (!((EduCraftPlugin) plugin).fixedArenaKeys().contains(arenaKey)) {
                    plugin.getLogger().warning("Rejected unknown arena key: " + arenaKey);
                    return;
                }
                Bukkit.getScheduler().runTask(plugin, () -> teleportToFixedKey(arenaKey));
            }
            case "RETURN_TO_LOBBY" -> Bukkit.getScheduler().runTask(plugin, () -> teleportToFixedKey(plugin.getConfig().getString("lobby-location")));
        }
    }

    private void teleportToFixedKey(String key) {
        World world = Bukkit.getWorld(plugin.getConfig().getString("fixed-world"));
        if (world == null) return;
        // Production deployments map these keys through a server-owned location registry.
        // This placeholder intentionally does not accept coordinates from API payloads.
        plugin.getLogger().info("Teleport requested for fixed location key: " + key);
    }
}