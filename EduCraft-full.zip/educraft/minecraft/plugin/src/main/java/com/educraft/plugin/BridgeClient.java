package com.educraft.plugin;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.Instant;
import java.util.HexFormat;
import java.util.UUID;

public final class BridgeClient {
    private final JavaPlugin plugin;
    private final HttpClient client = HttpClient.newHttpClient();
    private final Gson gson = new Gson();

    public BridgeClient(JavaPlugin plugin) { this.plugin = plugin; }
    public boolean isReady() { return !plugin.getConfig().getString("api-key", "").equals("change-me"); }

    public void recoverStaleSessions() {
        if (!isReady()) return;
        // Recovery endpoint is intentionally a bounded API call. No world reset happens here;
        // server-side session state decides which fixed arena can be cleaned.
        get("/health");
    }

    public void sendPlayerEvent(String sessionId, String type, String playerUuid, JsonObject payload) {
        JsonObject body = new JsonObject();
        body.addProperty("sessionId", sessionId);
        body.addProperty("type", type);
        body.addProperty("playerUuid", playerUuid);
        body.add("payload", payload);
        post("/minecraft/player-event", body.toString());
    }

    private void get(String path) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                HttpRequest request = signedRequest(path, "{}", "GET").build();
                client.send(request, HttpResponse.BodyHandlers.ofString());
            } catch (Exception error) { plugin.getLogger().warning("EduCraft bridge read failed: " + error.getMessage()); }
        });
    }

    private void post(String path, String body) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                HttpRequest request = signedRequest(path, body, "POST").header("Content-Type", "application/json").POST(HttpRequest.BodyPublishers.ofString(body)).build();
                client.send(request, HttpResponse.BodyHandlers.ofString());
            } catch (Exception error) { plugin.getLogger().warning("EduCraft bridge write failed: " + error.getMessage()); }
        });
    }

    private HttpRequest.Builder signedRequest(String path, String body, String method) throws Exception {
        long timestamp = Instant.now().getEpochSecond();
        String nonce = UUID.randomUUID().toString();
        String signature = hmac(timestamp + "." + nonce + "." + body);
        return HttpRequest.newBuilder(URI.create(plugin.getConfig().getString("api-base-url") + path))
                .header("X-EduCraft-Key", plugin.getConfig().getString("api-key"))
                .header("X-EduCraft-Timestamp", String.valueOf(timestamp))
                .header("X-EduCraft-Nonce", nonce)
                .header("X-EduCraft-Signature", signature);
    }

    private String hmac(String value) throws Exception {
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(plugin.getConfig().getString("api-secret").getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
        return HexFormat.of().formatHex(mac.doFinal(value.getBytes(StandardCharsets.UTF_8)));
    }
}