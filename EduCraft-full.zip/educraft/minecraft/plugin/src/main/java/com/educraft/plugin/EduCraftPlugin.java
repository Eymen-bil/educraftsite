package com.educraft.plugin;

import com.google.gson.JsonObject;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Set;

public final class EduCraftPlugin extends JavaPlugin {
    private BridgeClient bridge;
    private SafeActionDispatcher actions;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        bridge = new BridgeClient(this);
        actions = new SafeActionDispatcher(this);
        getCommand("educraft").setExecutor((sender, command, label, args) -> {
            sender.sendMessage("EduCraft bridge: " + (bridge.isReady() ? "connected" : "not connected"));
            return true;
        });
        Bukkit.getScheduler().runTaskTimerAsynchronously(this, bridge::recoverStaleSessions, 20L, 20L * 30L);
        getLogger().info("EduCraft Paper 1.21.8 bridge enabled. AI commands are disabled by design.");
    }

    public Set<String> fixedArenaKeys() {
        return Set.copyOf(getConfig().getStringList("arenas"));
    }

    public SafeActionDispatcher actions() { return actions; }
    public BridgeClient bridge() { return bridge; }
}