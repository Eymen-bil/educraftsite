import { BadRequestException, Injectable, UnauthorizedException } from "@nestjs/common";
import { JwtService } from "@nestjs/jwt";
import { ConfigService } from "@nestjs/config";
import { PrismaService } from "./prisma.service";
import * as bcrypt from "bcryptjs";
import { randomBytes, createHash } from "crypto";
import { Role } from "@prisma/client";

@Injectable()
export class AuthService {
  constructor(private prisma: PrismaService, private jwt: JwtService, private config: ConfigService) {}

  private safeUser(user: any) {
    const { passwordHash, ...safe } = user;
    return safe;
  }
  private hash(value: string) { return createHash("sha256").update(value).digest("hex"); }

  async login(email: string, password: string) {
    const user = await this.prisma.user.findUnique({ where: { email: email.toLowerCase() } });
    if (!user || !(await bcrypt.compare(password, user.passwordHash))) throw new UnauthorizedException("E-posta veya şifre hatalı.");
    return this.issue(user);
  }

  async register(input: { firstName: string; lastName: string; email: string; password: string; role?: Role; schoolCode?: string }) {
    const exists = await this.prisma.user.findUnique({ where: { email: input.email.toLowerCase() } });
    if (exists) throw new BadRequestException("Bu e-posta zaten kayıtlı.");
    const school = input.schoolCode ? await this.prisma.school.findUnique({ where: { code: input.schoolCode } }) : null;
    if (input.schoolCode && !school) throw new BadRequestException("Okul kodu bulunamadı.");
    const passwordHash = await bcrypt.hash(input.password, 12);
    const user = await this.prisma.user.create({
      data: { firstName: input.firstName, lastName: input.lastName, email: input.email.toLowerCase(), passwordHash, role: input.role === Role.STUDENT ? Role.STUDENT : Role.TEACHER, schoolId: school?.id },
    });
    return this.issue(user);
  }

  private async issue(user: any) {
    const payload = { sub: user.id, email: user.email, role: user.role, schoolId: user.schoolId };
    const accessToken = await this.jwt.signAsync(payload, { expiresIn: "15m" });
    const rawRefresh = randomBytes(48).toString("hex");
    await this.prisma.refreshToken.create({ data: { tokenHash: this.hash(rawRefresh), userId: user.id, expiresAt: new Date(Date.now() + 30 * 86400000) } });
    return { accessToken, refreshToken: rawRefresh, user: this.safeUser(user) };
  }

  async refresh(rawRefresh: string) {
    const token = await this.prisma.refreshToken.findFirst({ where: { tokenHash: this.hash(rawRefresh), revokedAt: null }, include: { user: true } });
    if (!token || token.expiresAt < new Date()) throw new UnauthorizedException("Refresh token geçersiz.");
    await this.prisma.refreshToken.update({ where: { id: token.id }, data: { revokedAt: new Date() } });
    return this.issue(token.user);
  }
}