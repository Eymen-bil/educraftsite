import { Module } from "@nestjs/common";
import { APP_GUARD } from "@nestjs/core";
import { ConfigModule, ConfigService } from "@nestjs/config";
import { JwtModule } from "@nestjs/jwt";
import { PrismaService } from "./prisma.service";
import { JwtGuard, RolesGuard } from "./auth";
import { AuthService } from "./auth.service";
import { AuthController } from "./auth.controller";
import { AiService } from "./ai.service";
import { AiController } from "./ai.controller";
import { GamesController } from "./games.controller";
import { SessionsController } from "./sessions.controller";
import { SessionsService } from "./sessions.service";
import { SessionsGateway } from "./sessions.gateway";
import { MinecraftController } from "./minecraft.controller";
import { HealthController } from "./health.controller";

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    JwtModule.registerAsync({ global: true, inject: [ConfigService], useFactory: (config: ConfigService) => ({ secret: config.getOrThrow("JWT_SECRET") }) }),
  ],
  controllers: [AuthController, AiController, GamesController, SessionsController, MinecraftController, HealthController],
  providers: [
    PrismaService, AuthService, AiService, SessionsService, SessionsGateway,
    { provide: APP_GUARD, useClass: JwtGuard },
    { provide: APP_GUARD, useClass: RolesGuard },
  ],
})
export class AppModule {}