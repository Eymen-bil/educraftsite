import { Body, Controller, Get, Param, Post, Req, UseGuards } from "@nestjs/common";
import { GameMode, Role, SessionStatus } from "@prisma/client";
import { z } from "zod";
import { AuthRequest, JwtGuard, Roles } from "./auth";
import { PrismaService } from "./prisma.service";
import { SessionsService } from "./sessions.service";

const createSchema = z.object({ gameId: z.string().uuid(), mode: z.enum(["CLASS", "SOLO"]) });
const answerSchema = z.object({ questionId: z.string().uuid(), selected: z.number().int().min(0).max(5), durationMs: z.number().int().min(0).optional() });

@Controller("sessions")
@UseGuards(JwtGuard)
export class SessionsController {
  constructor(private sessions: SessionsService, private prisma: PrismaService) {}
  @Get()
  list(@Req() req: AuthRequest) {
    return this.prisma.gameSession.findMany({ where: req.user.role === Role.STUDENT ? { players: { some: { userId: req.user.sub } } } : {}, include: { game: true, arena: true, players: { include: { user: { select: { firstName: true, lastName: true, email: true } } } } }, orderBy: { createdAt: "desc" }, take: 50 });
  }
  @Get(":id")
  detail(@Param("id") id: string) { return this.prisma.gameSession.findUniqueOrThrow({ where: { id }, include: { game: { include: { questions: true, quests: true, npcs: true, puzzles: true, boss: true } }, arena: true, players: { include: { user: true } } } }); }
  @Post()
  @Roles(Role.ADMIN, Role.SCHOOL_ADMIN, Role.TEACHER, Role.STUDENT)
  create(@Body() body: unknown) { const input = createSchema.parse(body); return this.sessions.create(input.gameId, input.mode as GameMode); }
  @Post(":id/join")
  join(@Param("id") id: string, @Req() req: AuthRequest) { return this.sessions.join(id, req.user.sub); }
  @Post(":id/status")
  @Roles(Role.ADMIN, Role.SCHOOL_ADMIN, Role.TEACHER)
  status(@Param("id") id: string, @Body("status") status: SessionStatus) { return this.sessions.transition(id, status); }
  @Post(":id/answer")
  answer(@Param("id") id: string, @Body() body: unknown, @Req() req: AuthRequest) { const input = answerSchema.parse(body); return this.sessions.answer(id, req.user.sub, input.questionId, input.selected, input.durationMs); }
}