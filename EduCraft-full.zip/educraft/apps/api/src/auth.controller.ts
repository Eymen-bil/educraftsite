import { Body, Controller, Post } from "@nestjs/common";
import { z } from "zod";
import { Public } from "./auth";
import { AuthService } from "./auth.service";

const loginSchema = z.object({ email: z.string().email(), password: z.string().min(8) });
const registerSchema = z.object({ firstName: z.string().min(2), lastName: z.string().min(2), email: z.string().email(), password: z.string().min(8), role: z.enum(["TEACHER", "STUDENT"]).optional(), schoolCode: z.string().optional() });

@Controller("auth")
export class AuthController {
  constructor(private auth: AuthService) {}
  @Public()
  @Post("login")
  login(@Body() body: unknown) { return this.auth.login(loginSchema.parse(body).email, loginSchema.parse(body).password); }
  @Public()
  @Post("register")
  register(@Body() body: unknown) { return this.auth.register(registerSchema.parse(body)); }
  @Public()
  @Post("refresh")
  refresh(@Body("refreshToken") token: string) { return this.auth.refresh(token); }
}