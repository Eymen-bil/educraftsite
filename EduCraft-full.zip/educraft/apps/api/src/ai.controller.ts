import { Body, Controller, Post, UseGuards } from "@nestjs/common";
import { AiService } from "./ai.service";
import { AuthRequest, Roles, JwtGuard, ROLES_KEY } from "./auth";
import { Role } from "@prisma/client";
import { Req } from "@nestjs/common";

@Controller("ai")
@UseGuards(JwtGuard)
export class AiController {
  constructor(private ai: AiService) {}
  @Post("generate")
  @Roles(Role.ADMIN, Role.SCHOOL_ADMIN, Role.TEACHER)
  generate(@Body() body: unknown, @Req() _req: AuthRequest) { return this.ai.generate(body); }
}