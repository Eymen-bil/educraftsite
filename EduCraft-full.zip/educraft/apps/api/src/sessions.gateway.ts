import { WebSocketGateway, WebSocketServer } from "@nestjs/websockets";
import { Server } from "socket.io";

@WebSocketGateway({ namespace: "/live", cors: { origin: true, credentials: true } })
export class SessionsGateway {
  @WebSocketServer() server!: Server;
  emitSession(sessionId: string, event: string, payload: unknown) {
    this.server.to(`session:${sessionId}`).emit(event, payload);
  }
  handleConnection(socket: any) {
    const sessionId = socket.handshake.auth?.sessionId || socket.handshake.query?.sessionId;
    if (sessionId) socket.join(`session:${sessionId}`);
  }
}