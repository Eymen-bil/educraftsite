import { Body, Controller, Get, Headers, Param, Post, Req, UnauthorizedException } from "@nestjs/common";
import { ConfigService } from "@nestjs/config";
import { createHmac, timingSafeEqual } from "crypto";
import { z } from "zod";
import { Public } from "./auth";
import { PrismaService } from "./prisma.service";
import { SessionsService } from "./sessions.service";
import { minecraftActionSchema } from "@educraft/schemas";

const playerEventSchema = z.object({ sessionId: z.string().uuid(), type: z.string(), playerUuid: z.string(), payload: z.record(z.unknown()).default({}) });

@Controller("minecraft")
export class MinecraftController {
  constructor(private prisma: PrismaService, private sessions: SessionsService, private config: ConfigService) {}

  private verify(@Headers("x-educraft-key") key: string, @Headers("x-educraft-timestamp") timestamp: string, @Headers("x-educraft-nonce") nonce: string, @Headers("x-educraft-signature") signature: string, raw: unknown) {
    const now = Math.floor(Date.now() / 1000);
    const skew = Number(this.config.get("MINECRAFT_ALLOWED_CLOCK_SKEW_SECONDS", 60));
    if (!key || key !== this.config.get("MINECRAFT_API_KEY") || !timestamp || Math.abs(now - Number(timestamp)) > skew || !nonce || !signature) throw new UnauthorizedException("Bridge imzası geçersiz.");
    const secret = this.config.getOrThrow("MINECRAFT_API_SECRET");
    const body = JSON.stringify(raw ?? {});
    const expected = createHmac("sha256", secret).update(`${timestamp}.${nonce}.${body}`).digest("hex");
    if (expected.length !== signature.length || !timingSafeEqual(Buffer.from(expected), Buffer.from(signature))) throw new UnauthorizedException("Bridge imzası geçersiz.");
    return this.prisma.nonce.create({ data: { value: nonce, expiresAt: new Date(Date.now() + skew * 1000) } }).catch(() => { throw new UnauthorizedException("Nonce daha önce kullanıldı."); });
  }

  @Public()
  @Get("session/:id")
  session(@Param("id") id: string, @Headers() headers: Record<string, string>) { return this.verify(headers["x-educraft-key"], headers["x-educraft-timestamp"], headers["x-educraft-nonce"], headers["x-educraft-signature"], { id }).then(() => this.prisma.gameSession.findUniqueOrThrow({ where: { id }, include: { game: { include: { questions: true, quests: true, npcs: true, puzzles: true, boss: true } }, arena: true } })); }

  @Public()
  @Post("player-event")
  async playerEvent(@Headers() headers: Record<string, string>, @Body() body: unknown) {
    await this.verify(headers["x-educraft-key"], headers["x-educraft-timestamp"], headers["x-educraft-nonce"], headers["x-educraft-signature"], body);
    const input = playerEventSchema.parse(body);
    return { accepted: true, sessionId: input.sessionId, event: input.type };
  }

  @Public()
  @Post("action")
  async action(@Headers() headers: Record<string, string>, @Body() body: unknown) {
    await this.verify(headers["x-educraft-key"], headers["x-educraft-timestamp"], headers["x-educraft-nonce"], headers["x-educraft-signature"], body);
    return minecraftActionSchema.parse(body);
  }
}