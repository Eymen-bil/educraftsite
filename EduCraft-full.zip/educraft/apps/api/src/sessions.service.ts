import { BadRequestException, Injectable, NotFoundException } from "@nestjs/common";
import { GameMode, SessionStatus } from "@prisma/client";
import { PrismaService } from "./prisma.service";
import { SessionsGateway } from "./sessions.gateway";

@Injectable()
export class SessionsService {
  constructor(private prisma: PrismaService, private gateway: SessionsGateway) {}

  async create(gameId: string, mode: GameMode) {
    const arena = await this.prisma.arena.findFirst({ where: { status: "AVAILABLE" }, orderBy: { createdAt: "asc" } });
    if (!arena) throw new BadRequestException("Şu anda kullanılabilir arena yok.");
    return this.prisma.$transaction(async (tx) => {
      await tx.arena.update({ where: { id: arena.id }, data: { status: "IN_USE" } });
      return tx.gameSession.create({ data: { gameId, mode, arenaId: arena.id }, include: { game: true, arena: true, players: true } });
    });
  }

  async join(sessionId: string, userId: string) {
    const session = await this.prisma.gameSession.findUnique({ where: { id: sessionId } });
    const joinable: SessionStatus[] = [SessionStatus.WAITING, SessionStatus.STARTING, SessionStatus.RUNNING];
    if (!session || !joinable.includes(session.status)) throw new NotFoundException("Session katılım için açık değil.");
    if (session.mode === GameMode.SOLO) {
      const count = await this.prisma.sessionPlayer.count({ where: { sessionId } });
      if (count > 0) throw new BadRequestException("Solo session dolu.");
    }
    const player = await this.prisma.sessionPlayer.upsert({ where: { sessionId_userId: { sessionId, userId } }, update: { online: true }, create: { sessionId, userId, online: true } });
    this.gateway.emitSession(sessionId, "PLAYER_JOINED", player);
    return player;
  }

  async transition(sessionId: string, next: SessionStatus) {
    const session = await this.prisma.gameSession.findUnique({ where: { id: sessionId }, include: { arena: true } });
    if (!session) throw new NotFoundException("Session bulunamadı.");
    const allowed: Record<SessionStatus, SessionStatus[]> = {
      WAITING: [SessionStatus.STARTING, SessionStatus.CLOSED], STARTING: [SessionStatus.RUNNING, SessionStatus.CLOSED],
      RUNNING: [SessionStatus.PAUSED, SessionStatus.COMPLETED, SessionStatus.CLOSED], PAUSED: [SessionStatus.RUNNING, SessionStatus.CLOSED],
      COMPLETED: [SessionStatus.CLEANING], CLEANING: [SessionStatus.CLOSED], CLOSED: [], 
    };
    if (!allowed[session.status].includes(next)) throw new BadRequestException(`Geçersiz session geçişi: ${session.status} → ${next}`);
    const updated = await this.prisma.$transaction(async (tx) => {
      const result = await tx.gameSession.update({ where: { id: sessionId }, data: { status: next, startedAt: next === SessionStatus.RUNNING ? new Date() : undefined, endedAt: next === SessionStatus.CLOSED ? new Date() : undefined } });
      if (next === SessionStatus.CLOSED && session.arenaId) await tx.arena.update({ where: { id: session.arenaId }, data: { status: "AVAILABLE" } });
      return result;
    });
    this.gateway.emitSession(sessionId, `SESSION_${next}`, updated);
    return updated;
  }

  async answer(sessionId: string, userId: string, questionId: string, selected: number, durationMs?: number) {
    const question = await this.prisma.question.findUnique({ where: { id: questionId } });
    if (!question) throw new NotFoundException("Soru bulunamadı.");
    const result = selected === question.correctOption ? "CORRECT" : "INCORRECT";
    const attempt = await this.prisma.answerAttempt.create({ data: { sessionId, questionId, userId, selected, durationMs, result } });
    await this.prisma.sessionPlayer.update({ where: { sessionId_userId: { sessionId, userId } }, data: { score: { increment: result === "CORRECT" ? 10 : 0 }, xp: { increment: result === "CORRECT" ? 10 : 2 } } });
    this.gateway.emitSession(sessionId, "PLAYER_ANSWERED", { userId, questionId, result, attemptId: attempt.id });
    return { correct: result === "CORRECT", explanation: question.explanation, attempt };
  }
}