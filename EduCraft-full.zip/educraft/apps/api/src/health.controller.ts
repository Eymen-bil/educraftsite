import { Controller, Get } from "@nestjs/common";
import { Public } from "./auth";
import { PrismaService } from "./prisma.service";

@Controller("health")
export class HealthController {
  constructor(private prisma: PrismaService) {}
  @Public()
  @Get()
  async health() {
    let database: "ONLINE" | "OFFLINE" = "ONLINE";
    try { await this.prisma.$queryRaw`SELECT 1`; } catch { database = "OFFLINE"; }
    return { website: "ONLINE", api: "ONLINE", database, minecraftBridge: "CONFIGURED", ai: process.env.AI_API_KEY ? "ONLINE" : "NOT_CONFIGURED", checkedAt: new Date().toISOString() };
  }
}