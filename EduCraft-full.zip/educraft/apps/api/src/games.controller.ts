import { Body, Controller, Get, Param, Post, Req, UseGuards } from "@nestjs/common";
import { Prisma, Role } from "@prisma/client";
import { createGameSchema, gameContentSchema } from "@educraft/schemas";
import { AuthRequest, JwtGuard, Roles } from "./auth";
import { PrismaService } from "./prisma.service";

@Controller("games")
@UseGuards(JwtGuard)
export class GamesController {
  constructor(private prisma: PrismaService) {}

  @Get()
  list(@Req() req: AuthRequest) {
    return this.prisma.game.findMany({ where: req.user.role === Role.TEACHER ? { creatorId: req.user.sub } : {}, include: { topic: true, _count: { select: { questions: true, quests: true, sessions: true } } }, orderBy: { createdAt: "desc" } });
  }

  @Get(":id")
  detail(@Param("id") id: string) { return this.prisma.game.findUniqueOrThrow({ where: { id }, include: { questions: true, quests: { include: { steps: true } }, npcs: true, puzzles: true, boss: true, rewards: true, topic: true } }); }

  @Post()
  @Roles(Role.ADMIN, Role.SCHOOL_ADMIN, Role.TEACHER)
  async create(@Body() body: unknown, @Req() req: AuthRequest) {
    const input = createGameSchema.parse(body);
    const subject = await this.prisma.subject.create({ data: { name: input.subject, schoolId: req.user.schoolId || undefined } });
    const topic = await this.prisma.topic.create({ data: { name: input.topic, subjectId: subject.id } });
    return this.prisma.game.create({
      data: {
        title: input.title, gradeLevel: input.gradeLevel, durationMinutes: input.durationMinutes,
        difficulty: input.difficulty, adaptiveMode: input.adaptiveMode, mode: input.mode,
        creatorId: req.user.sub, subjectId: subject.id, topicId: topic.id,
      },
    });
  }

  @Post(":id/content")
  @Roles(Role.ADMIN, Role.SCHOOL_ADMIN, Role.TEACHER)
  async saveContent(@Param("id") id: string, @Body() body: unknown) {
    const content = gameContentSchema.parse(body);
    return this.prisma.$transaction(async (tx) => {
      await tx.question.deleteMany({ where: { gameId: id } });
      await tx.quest.deleteMany({ where: { gameId: id } });
      await tx.nPC.deleteMany({ where: { gameId: id } });
      await tx.puzzle.deleteMany({ where: { gameId: id } });
      await tx.boss.deleteMany({ where: { gameId: id } });
      await tx.reward.deleteMany({ where: { gameId: id } });
      return tx.game.update({ where: { id }, data: {
        questions: { create: content.questions.map(({ id: _id, options, ...q }) => ({ ...q, options })) },
        quests: { create: content.quests.map((q) => ({ title: q.title, description: q.description, type: q.type, rewardXp: q.rewardXp, steps: { create: q.steps.map((s, order) => ({ ...s, order })) } })) },
        npcs: { create: content.npcs.map(({ id: _id, ...n }) => n) },
        puzzles: { create: content.puzzles.map(({ id: _id, data, ...p }) => ({ ...p, data: data as Prisma.InputJsonValue })) },
        boss: content.boss.enabled ? { create: content.boss } : undefined,
        rewards: { create: content.rewards },
      }, include: { questions: true, quests: { include: { steps: true } }, npcs: true, puzzles: true, boss: true, rewards: true } });
    });
  }
}