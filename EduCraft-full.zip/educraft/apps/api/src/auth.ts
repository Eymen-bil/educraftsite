import {
  CanActivate, ExecutionContext, Injectable, SetMetadata, UnauthorizedException,
} from "@nestjs/common";
import { JwtService } from "@nestjs/jwt";
import { Reflector } from "@nestjs/core";
import { Request } from "express";
import { Role } from "@prisma/client";

export const IS_PUBLIC = "isPublic";
export const Public = () => SetMetadata(IS_PUBLIC, true);
export const ROLES_KEY = "roles";
export const Roles = (...roles: Role[]) => SetMetadata(ROLES_KEY, roles);

export interface AuthRequest extends Request {
  user: { sub: string; email: string; role: Role; schoolId?: string | null };
}

@Injectable()
export class JwtGuard implements CanActivate {
  constructor(private jwt: JwtService, private reflector: Reflector) {}
  canActivate(context: ExecutionContext): boolean {
    if (this.reflector.getAllAndOverride<boolean>(IS_PUBLIC, [context.getHandler(), context.getClass()])) return true;
    const req = context.switchToHttp().getRequest<AuthRequest>();
    const token = (req.headers.authorization || "").replace("Bearer ", "");
    if (!token) throw new UnauthorizedException("Oturum gerekli.");
    try { req.user = this.jwt.verify(token); return true; } catch { throw new UnauthorizedException("Oturum süresi doldu."); }
  }
}

@Injectable()
export class RolesGuard implements CanActivate {
  constructor(private reflector: Reflector) {}
  canActivate(context: ExecutionContext): boolean {
    const required = this.reflector.getAllAndOverride<Role[]>(ROLES_KEY, [context.getHandler(), context.getClass()]);
    if (!required?.length) return true;
    const req = context.switchToHttp().getRequest<AuthRequest>();
    if (!required.includes(req.user.role)) throw new UnauthorizedException("Bu işlem için yetkiniz yok.");
    return true;
  }
}