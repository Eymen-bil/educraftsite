import Dashboard from "../../../dashboard/page";
export default function CreateGamePage() { return <Dashboard forcedRole="TEACHER" />; }