import Dashboard from "../../dashboard/page";
export default function TeacherDashboard() { return <Dashboard forcedRole="TEACHER" />; }