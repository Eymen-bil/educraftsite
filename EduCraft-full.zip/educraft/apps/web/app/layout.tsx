import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "EduCraft | Öğren, Oyna, Keşfet",
  description: "Minecraft'ın etkileşimli dünyasını eğitimle birleştiren platform.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="tr"><body>{children}</body></html>;
}