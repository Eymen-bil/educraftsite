import Dashboard from "../../dashboard/page";
export default function StudentDashboard() { return <Dashboard forcedRole="STUDENT" />; }