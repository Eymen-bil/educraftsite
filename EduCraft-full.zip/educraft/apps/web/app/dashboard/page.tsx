"use client";

import { FormEvent, useEffect, useState } from "react";
import Link from "next/link";
import {
  Activity, BarChart3, BookOpen, ChevronDown, CircleHelp, Gamepad2, LayoutDashboard,
  LogOut, Menu, Plus, Settings, ShieldCheck, Sparkles, Users, X, Zap,
} from "lucide-react";
import { api, currentUser } from "../../lib/api";

type User = { firstName: string; lastName: string; role: "ADMIN" | "SCHOOL_ADMIN" | "TEACHER" | "STUDENT" };
type Game = {
  id: string; title: string; gradeLevel: string; durationMinutes: number; difficulty: string;
  topic?: { name: string }; _count?: { questions: number; quests: number; sessions: number };
};

export default function Dashboard({ forcedRole }: { forcedRole?: User["role"] } = {}) {
  const [user, setUser] = useState<User | null>(null);
  const [games, setGames] = useState<Game[]>([]);
  const [message, setMessage] = useState("");
  const [showCreate, setShowCreate] = useState(false);
  const [busy, setBusy] = useState(false);
  const [menu, setMenu] = useState(false);

  useEffect(() => {
    const saved = currentUser<User>();
    setUser(saved);
    if (saved) api<Game[]>("/games").then(setGames).catch(() => {});
  }, []);

  const role = forcedRole || user?.role || "TEACHER";
  const student = role === "STUDENT";
  const admin = role === "ADMIN" || role === "SCHOOL_ADMIN";

  function logout() {
    localStorage.clear();
    location.href = "/";
  }

  async function createGame(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    const values = Object.fromEntries(new FormData(event.currentTarget));
    try {
      await api("/games", {
        method: "POST",
        body: JSON.stringify({
          ...values,
          durationMinutes: Number(values.durationMinutes),
          adaptiveMode: values.difficulty === "ADAPTIVE",
        }),
      });
      setMessage("Oyun taslağı oluşturuldu.");
      setShowCreate(false);
      setGames(await api<Game[]>("/games"));
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Oyun oluşturulamadı.");
    } finally {
      setBusy(false);
    }
  }

  async function generateContent(game: Game) {
    setBusy(true);
    try {
      const content = await api("/ai/generate", {
        method: "POST",
        body: JSON.stringify({
          title: game.title, subject: "Matematik", topic: game.topic?.name || "Denklemler",
          gradeLevel: game.gradeLevel, difficulty: game.difficulty, questionCount: 5, questCount: 2,
        }),
      });
      await api(`/games/${game.id}/content`, { method: "POST", body: JSON.stringify(content) });
      setMessage("AI içeriği şemadan geçirildi ve oyuna kaydedildi.");
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "AI içeriği oluşturulamadı.");
    } finally {
      setBusy(false);
    }
  }

  const metrics = student
    ? [["TOPLAM XP", "1.240", "+180 bu hafta", "gold"], ["SEVİYE", "8", "Sonraki: 260 XP", "purple"], ["TAMAMLANAN OYUN", "12", "+3 bu ay", "blue"], ["ORT. BAŞARI", "%84", "+%6 gelişim", "green"]]
    : admin
      ? [["TOPLAM KULLANICI", "1.284", "+18 bu hafta", "gold"], ["AKTİF OKUL", "12", "+2 bu ay", "purple"], ["CANLI SESSION", "8", "3 başlamak üzere", "blue"], ["SİSTEM SAĞLIĞI", "%99.9", "Son 30 gün", "green"]]
      : [["AKTİF SINIFLAR", "6", "+12% bu ay", "gold"], ["TOPLAM ÖĞRENCİ", "142", "+8% bu ay", "purple"], ["AKTİF OYUNLAR", "9", "3 bugün oynanıyor", "blue"], ["ORT. BAŞARI", "%84", "+5% bu hafta", "green"]];

  return (
    <div className="app-shell">
      <aside className={`sidebar ${menu ? "open" : ""}`}>
        <div className="sidebar-head">
          <Link href="/" className="brand"><span className="brand-mark">E</span><span>EduCraft</span></Link>
          <button className="icon-button mobile-only" onClick={() => setMenu(false)}><X size={18} /></button>
        </div>
        <div className="workspace-switch"><span className="school-mark">E</span><div><b>EduCraft Demo Okulu</b><small>{student ? "Öğrenci alanı" : admin ? "Yönetim alanı" : "Öğretmen alanı"}</small></div><ChevronDown size={15} /></div>
        <nav className="side-nav">
          <small>MENÜ</small>
          <SideLink icon={<LayoutDashboard />} text="Genel bakış" active />
          <SideLink icon={<BookOpen />} text={student ? "Oyunlarım" : "Oyunlar"} />
          <SideLink icon={<Users />} text={student ? "Sınıflarım" : "Sınıflar"} />
          <SideLink icon={<BarChart3 />} text="Analitik" />
          <SideLink icon={<Gamepad2 />} text="Minecraft" />
          <small className="nav-gap">YÖNETİM</small>
          {admin && <SideLink icon={<ShieldCheck />} text="Admin paneli" />}
          <SideLink icon={<Settings />} text="Ayarlar" />
        </nav>
        <div className="sidebar-bottom">
          <div className="help-card"><CircleHelp size={17} /><div><b>Yardıma mı ihtiyacın var?</b><span>Rehber merkezine git →</span></div></div>
          <button className="logout-button" onClick={logout}><LogOut size={17} /> Çıkış yap</button>
        </div>
      </aside>

      <div className="main-area">
        <header className="topbar">
          <button className="icon-button mobile-only" onClick={() => setMenu(true)}><Menu size={20} /></button>
          <div className="crumb"><span>EduCraft</span><b>/</b><strong>Genel bakış</strong></div>
          <div className="top-actions"><span className="system-status"><i /> Tüm sistemler çalışıyor</span><button className="icon-button"><Activity size={18} /></button><div className="profile"><span className="avatar">{user?.firstName?.[0] || "A"}{user?.lastName?.[0] || "Y"}</span><div><b>{user ? `${user.firstName} ${user.lastName}` : "Misafir"}</b><small>{student ? "Öğrenci" : admin ? "Yönetici" : "Öğretmen"}</small></div><ChevronDown size={15} /></div></div>
        </header>

        <main className="content">
          <div className="welcome-row"><div><span className="eyebrow">{student ? "ÖĞRENME MERKEZİ" : admin ? "SİSTEM ÖZETİ" : "ÖĞRETMEN PANELİ"}</span><h1>{student ? "Hazır mısın, maceracı? 👋" : `Günaydın, ${user?.firstName || "öğretmen"} 👋`}</h1><p>{student ? "Bugün yeni bir şey keşfetmek için güzel bir gün." : "Sınıfının öğrenme yolculuğu bugün nasıl gidiyor?"}</p></div>{!student && <button className="button" onClick={() => setShowCreate(true)}><Plus size={18} /> Yeni oyun</button>}</div>
          {message && <div className="success-banner"><span className="check-icon">✓</span>{message}<button onClick={() => setMessage("")}>×</button></div>}
          <div className="metric-grid">{metrics.map(([label, value, note, color]) => <div className="metric-card" key={label}><div className={`metric-symbol ${color}`}><Zap size={17} /></div><span>{label}</span><strong>{value}</strong><small className={note.startsWith("+") ? "positive" : ""}>{note}</small></div>)}</div>

          <div className="dashboard-grid">
            <section className="panel progress-panel"><div className="panel-head"><div><span className="eyebrow">İLERLEME</span><h2>{student ? "Konu mastery" : "Öğrenci ilerlemesi"}</h2></div><button className="select-button">Son 7 gün <ChevronDown size={14} /></button></div><div className="chart-area"><div className="y-labels"><span>100%</span><span>75%</span><span>50%</span><span>25%</span><span>0%</span></div><div className="chart-lines"><i /><i /><i /><i /><div className="chart-bars">{[42, 55, 48, 70, 62, 82, 91].map((height, index) => <b key={index} style={{ height: `${height}%` }} />)}</div><div className="x-labels">{["Pzt", "Sal", "Çar", "Per", "Cum", "Cmt", "Paz"].map((day) => <span key={day}>{day}</span>)}</div></div></div></section>
            <section className="panel mastery-panel"><div className="panel-head"><div><span className="eyebrow">MASTERY</span><h2>Konu dağılımı</h2></div><BarChart3 size={19} className="muted-icon" /></div><div className="mastery-list"><Mastery name="Denklemler" value={82} color="gold" /><Mastery name="Kesirler" value={54} color="purple" /><Mastery name="Geometri" value={91} color="blue" /><Mastery name="Olasılık" value={67} color="green" /></div><Link href="/dashboard" className="panel-link">Tüm analitiği gör <span className="arrow">→</span></Link></section>
          </div>

          <section className="panel games-panel"><div className="panel-head"><div><span className="eyebrow">{student ? "DEVAM ET" : "OYUNLAR"}</span><h2>{student ? "Aktif maceralar" : "Son oyunlar"}</h2></div><div className="head-actions"><button className="filter-button">Tümü <ChevronDown size={14} /></button>{!student && <button className="panel-link" onClick={() => setShowCreate(true)}>Tümünü gör <span className="arrow">→</span></button>}</div></div>
            {games.length === 0 ? <div className="empty-state"><Gamepad2 size={28} /><b>Henüz oyun yok</b><span>İlk eğitim oyununu oluşturarak başla.</span>{!student && <button className="button button-small" onClick={() => setShowCreate(true)}><Plus size={15} /> Oyun oluştur</button>}</div> : <div className="game-table"><div className="table-head"><span>OYUN</span><span>KONU</span><span>DURUM</span><span>İLERLEME</span><span /></div>{games.slice(0, 5).map((game) => <div className="table-row" key={game.id}><div className="game-name"><span className="game-avatar"><Gamepad2 size={17} /></span><div><b>{game.title}</b><small>{game.gradeLevel} · {game.durationMinutes} dk</small></div></div><span>{game.topic?.name || "Eğitim içeriği"}</span><span className="badge badge-green">Hazır</span><div className="mini-progress"><i style={{ width: `${Math.min(96, 35 + (game._count?.questions || 0) * 7)}%` }} /></div><button className="row-menu">•••</button>{!student && <button className="content-action" onClick={() => generateContent(game)} disabled={busy}><Sparkles size={14} /> AI içerik</button>}</div>)}</div>}
          </section>
        </main>
      </div>

      {showCreate && <div className="modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) setShowCreate(false); }}><div className="modal"><div className="modal-head"><div><span className="eyebrow">YENİ OYUN</span><h2>Macera tasarla</h2></div><button className="icon-button" onClick={() => setShowCreate(false)}>×</button></div><form onSubmit={createGame} className="game-form"><label>Oyun adı<input name="title" placeholder="Kayıp Cebir Krallığı" required /></label><div className="form-row"><label>Ders<input name="subject" placeholder="Matematik" required /></label><label>Konu<input name="topic" placeholder="Denklemler" required /></label></div><div className="form-row"><label>Sınıf seviyesi<select name="gradeLevel" defaultValue="7. Sınıf"><option>5. Sınıf</option><option>6. Sınıf</option><option>7. Sınıf</option><option>8. Sınıf</option></select></label><label>Süre<select name="durationMinutes" defaultValue="30"><option value="15">15 dakika</option><option value="30">30 dakika</option><option value="45">45 dakika</option></select></label></div><div className="form-row"><label>Zorluk<select name="difficulty" defaultValue="ADAPTIVE"><option value="ADAPTIVE">Adaptive</option><option value="EASY">Kolay</option><option value="MEDIUM">Orta</option><option value="HARD">Zor</option></select></label><label>Oyun modu<select name="mode" defaultValue="CLASS"><option value="CLASS">Sınıf</option><option value="SOLO">Solo</option></select></label></div><button className="button submit-button" disabled={busy}>{busy ? "Oluşturuluyor..." : "Oyunu oluştur"} <span className="arrow">→</span></button></form></div></div>}
    </div>
  );
}

function SideLink({ icon, text, active }: { icon: React.ReactNode; text: string; active?: boolean }) {
  return <a className={`side-link ${active ? "active" : ""}`} href="#"><span>{icon}</span>{text}{active && <i />}</a>;
}

function Mastery({ name, value, color }: { name: string; value: number; color: string }) {
  return <div className="mastery-row"><div><span>{name}</span><b>{value}%</b></div><div className="mastery-track"><i className={color} style={{ width: `${value}%` }} /></div></div>;
}