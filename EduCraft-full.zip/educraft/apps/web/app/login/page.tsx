"use client";
import { FormEvent, useEffect, useState } from "react";
import Link from "next/link";
import { ArrowLeft, Eye, EyeOff, Loader2 } from "lucide-react";
import { api, saveAuth } from "../../lib/api";
import { useRouter } from "next/navigation";

export default function LoginPage() {
  const router = useRouter();
  const [register, setRegister] = useState(false); const [show, setShow] = useState(false); const [loading, setLoading] = useState(false); const [error, setError] = useState("");
  useEffect(() => setRegister(new URLSearchParams(window.location.search).get("register") === "1"), []);
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setLoading(true); setError("");
    const data = Object.fromEntries(new FormData(event.currentTarget));
    try {
      const result = await api<any>(register ? "/auth/register" : "/auth/login", { method: "POST", body: JSON.stringify(register ? { ...data, role: data.role || "TEACHER" } : data) });
      saveAuth(result); router.push(result.user.role === "STUDENT" ? "/student/dashboard" : result.user.role === "ADMIN" ? "/admin" : "/teacher/dashboard");
    } catch (e) { setError(e instanceof Error ? e.message : "İşlem başarısız."); } finally { setLoading(false); }
  }
  return <main className="auth-page"><div className="auth-art"><Link href="/" className="brand light-brand"><span className="brand-mark">E</span><span>EduCraft</span></Link><div className="auth-art-copy"><span className="eyebrow light">ÖĞRENME MACERASI BAŞLIYOR</span><h1>Her dersin<br /><em>bir hikayesi</em> var.</h1><p>Sınıfını Minecraft’ın içine taşı, öğrenmeyi unutulmaz hale getir.</p></div><div className="auth-art-bottom"><span>“Çocuklar soruları çözmek için değil, macerayı tamamlamak için yarışıyor.”</span><b>— Fen Bilimleri Öğretmeni, Zeynep K.</b></div></div><div className="auth-form-wrap"><Link href="/" className="back-link"><ArrowLeft size={16} /> Ana sayfaya dön</Link><div className="auth-form"><span className="eyebrow">{register ? "HESAP OLUŞTUR" : "TEKRAR HOŞ GELDİN"}</span><h2>{register ? "Öğrenme alanını kur." : "Maceraya devam et."}</h2><p>{register ? "Sınıfın için güvenli oyunlar tasarlamaya başla." : "EduCraft hesabınla devam et."}</p><form onSubmit={submit}>{register && <div className="form-row"><label>Ad<input name="firstName" placeholder="Ayşe" required /></label><label>Soyad<input name="lastName" placeholder="Yılmaz" required /></label></div>}<label>E-posta<input type="email" name="email" placeholder="ornek@okul.com" required /></label><label>Şifre<div className="password-input"><input type={show ? "text" : "password"} name="password" placeholder="En az 8 karakter" minLength={8} required /><button type="button" onClick={() => setShow(!show)}>{show ? <EyeOff size={17} /> : <Eye size={17} />}</button></div></label>{register && <label>Rol<select name="role" defaultValue="TEACHER"><option value="TEACHER">Öğretmen</option><option value="STUDENT">Öğrenci</option></select></label>}{error && <div className="form-error">{error}</div>}<button className="button submit-button" disabled={loading}>{loading ? <Loader2 className="spin" size={18} /> : null}{register ? "Hesap oluştur" : "Giriş yap"} {!loading && "→"}</button></form><div className="auth-switch">{register ? "Zaten hesabın var mı?" : "İlk kez mi geliyorsun?"} <button onClick={() => setRegister(!register)}>{register ? "Giriş yap" : "Hesap oluştur"}</button></div></div></div></main>;
}