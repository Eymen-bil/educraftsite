const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:4000/api";

export function getToken() { return typeof window === "undefined" ? null : localStorage.getItem("educraft_access_token"); }
export async function api<T>(path: string, options: RequestInit = {}): Promise<T> {
  const token = getToken();
  const response = await fetch(`${API_URL}${path}`, {
    ...options,
    headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}), ...(options.headers || {}) },
  });
  if (!response.ok) {
    const error = await response.json().catch(() => ({}));
    throw new Error(error.message || "İstek tamamlanamadı.");
  }
  return response.json();
}
export function saveAuth(data: { accessToken: string; refreshToken: string; user: unknown }) {
  localStorage.setItem("educraft_access_token", data.accessToken);
  localStorage.setItem("educraft_refresh_token", data.refreshToken);
  localStorage.setItem("educraft_user", JSON.stringify(data.user));
}
export function currentUser<T = any>(): T | null {
  try { return JSON.parse(localStorage.getItem("educraft_user") || "null"); } catch { return null; }
}